"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"

type Choice = "rock" | "paper" | "scissors"

interface GameResponse {
  user_choice: Choice
  computer_choice: Choice
  result: "win" | "lose" | "draw"
  message: string
}

export default function ApiIntegration() {
  const [backendUrl, setBackendUrl] = useState("http://localhost:5000")
  const [isConnected, setIsConnected] = useState(false)
  const [gameResult, setGameResult] = useState<GameResponse | null>(null)
  const [isLoading, setIsLoading] = useState(false)

  const testConnection = async () => {
    try {
      const response = await fetch(`${backendUrl}/health`)
      if (response.ok) {
        setIsConnected(true)
        alert("Successfully connected to Flask backend!")
      } else {
        setIsConnected(false)
        alert("Failed to connect to Flask backend")
      }
    } catch (error) {
      setIsConnected(false)
      alert("Error connecting to Flask backend: " + error)
    }
  }

  const playGameWithBackend = async (choice: Choice) => {
    if (!isConnected) {
      alert("Please connect to the Flask backend first")
      return
    }

    setIsLoading(true)
    try {
      const response = await fetch(`${backendUrl}/play`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ choice }),
      })

      if (response.ok) {
        const result: GameResponse = await response.json()
        setGameResult(result)
      } else {
        alert("Error playing game")
      }
    } catch (error) {
      alert("Error connecting to backend: " + error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card className="w-full max-w-md mx-auto mt-8">
      <CardHeader>
        <CardTitle>Flask Backend Integration</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label htmlFor="backend-url">Backend URL</Label>
          <Input
            id="backend-url"
            value={backendUrl}
            onChange={(e) => setBackendUrl(e.target.value)}
            placeholder="http://localhost:5000"
          />
        </div>

        <Button onClick={testConnection} className="w-full">
          Test Connection
        </Button>

        {isConnected && (
          <Alert>
            <AlertDescription>✅ Connected to Flask backend successfully!</AlertDescription>
          </Alert>
        )}

        {isConnected && (
          <div className="space-y-2">
            <h3 className="font-semibold">Play with Real Backend:</h3>
            <div className="grid grid-cols-3 gap-2">
              {(["rock", "paper", "scissors"] as Choice[]).map((choice) => (
                <Button
                  key={choice}
                  onClick={() => playGameWithBackend(choice)}
                  disabled={isLoading}
                  variant="outline"
                  size="sm"
                >
                  {choice}
                </Button>
              ))}
            </div>
          </div>
        )}

        {gameResult && (
          <div className="text-center p-4 bg-gray-50 rounded">
            <p>
              <strong>You:</strong> {gameResult.user_choice}
            </p>
            <p>
              <strong>Computer:</strong> {gameResult.computer_choice}
            </p>
            <p>
              <strong>Result:</strong> {gameResult.message}
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
