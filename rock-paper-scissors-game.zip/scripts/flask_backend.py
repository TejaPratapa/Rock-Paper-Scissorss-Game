from flask import Flask, request, jsonify
from flask_cors import CORS
import random

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Game choices
CHOICES = ['rock', 'paper', 'scissors']

def determine_winner(user_choice, computer_choice):
    """Determine the winner of the game"""
    if user_choice == computer_choice:
        return 'draw', "It's a draw!"
    
    winning_combinations = {
        ('rock', 'scissors'): 'win',
        ('paper', 'rock'): 'win',
        ('scissors', 'paper'): 'win'
    }
    
    if (user_choice, computer_choice) in winning_combinations:
        return 'win', 'You win!'
    else:
        return 'lose', 'Computer wins!'

@app.route('/play', methods=['POST'])
def play_game():
    """Handle game play request"""
    try:
        data = request.get_json()
        user_choice = data.get('choice', '').lower()
        
        # Validate user choice
        if user_choice not in CHOICES:
            return jsonify({
                'error': 'Invalid choice. Must be rock, paper, or scissors.'
            }), 400
        
        # Generate computer choice
        computer_choice = random.choice(CHOICES)
        
        # Determine winner
        result, message = determine_winner(user_choice, computer_choice)
        
        # Return game result
        return jsonify({
            'user_choice': user_choice,
            'computer_choice': computer_choice,
            'result': result,
            'message': message
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({'status': 'healthy', 'message': 'Rock Paper Scissors API is running!'})

@app.route('/', methods=['GET'])
def home():
    """Home endpoint with API information"""
    return jsonify({
        'message': 'Rock Paper Scissors API',
        'endpoints': {
            '/play': 'POST - Play a game (send {"choice": "rock|paper|scissors"})',
            '/health': 'GET - Health check'
        }
    })

if __name__ == '__main__':
    print("Starting Rock Paper Scissors Flask Backend...")
    print("API Endpoints:")
    print("- POST /play - Play a game")
    print("- GET /health - Health check")
    print("- GET / - API information")
    app.run(debug=True, host='0.0.0.0', port=5000)
