"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import Image from "next/image"

type Choice = "rock" | "paper" | "scissors"
type GameResult = "win" | "lose" | "draw"
type GameMode = "classic" | "bestof3" | "tournament" | "speed"
type Theme = "arena" | "casino" | "dojo" | "cyber"

interface GameResponse {
  user_choice: Choice
  computer_choice: Choice
  result: GameResult
  message: string
}

interface GameState {
  currentRound: number
  totalRounds: number
  userScore: number
  computerScore: number
  gameHistory: GameResponse[]
  isGameComplete: boolean
}

const choiceImages = {
  rock: "/images/rock2.png",
  paper: "/images/paper.png",
  scissors: "✂️", // Keep emoji for scissors
}

const choiceNames = {
  rock: "Rock",
  paper: "Paper",
  scissors: "Scissors",
}

const themes = {
  arena: {
    name: "Battle Arena",
    background: "bg-gradient-to-b from-stone-800 via-stone-700 to-stone-900",
    accent: "from-amber-400 to-orange-600",
    cardBg: "bg-stone-100/95 backdrop-blur-sm border-stone-300",
    buttonStyle: "bg-stone-200 hover:bg-stone-300 border-stone-400 text-stone-800",
    titleText: "text-amber-400",
    primaryText: "text-amber-600",
    secondaryText: "text-stone-700",
    accentText: "text-orange-600",
    labelText: "text-stone-800",
    descriptionText: "text-stone-600",
    playerText: "text-amber-700",
    computerText: "text-orange-700",
    winText: "text-amber-500",
    loseText: "text-red-600",
    drawText: "text-stone-600",
  },
  casino: {
    name: "Vegas Casino",
    background: "bg-gradient-to-br from-red-900 via-red-800 to-black",
    accent: "from-yellow-400 to-red-600",
    cardBg: "bg-red-50/95 backdrop-blur-sm border-red-200",
    buttonStyle: "bg-red-100 hover:bg-red-200 border-red-300 text-red-900",
    titleText: "text-yellow-400",
    primaryText: "text-red-600",
    secondaryText: "text-red-700",
    accentText: "text-yellow-600",
    labelText: "text-red-800",
    descriptionText: "text-red-600",
    playerText: "text-yellow-700",
    computerText: "text-red-700",
    winText: "text-yellow-500",
    loseText: "text-red-600",
    drawText: "text-red-500",
  },
  dojo: {
    name: "Ancient Dojo",
    background: "bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900",
    accent: "from-blue-400 to-purple-600",
    cardBg: "bg-slate-100/95 backdrop-blur-sm border-slate-300",
    buttonStyle: "bg-slate-200 hover:bg-slate-300 border-slate-400 text-slate-800",
    titleText: "text-blue-400",
    primaryText: "text-blue-600",
    secondaryText: "text-slate-700",
    accentText: "text-purple-600",
    labelText: "text-slate-800",
    descriptionText: "text-slate-600",
    playerText: "text-blue-700",
    computerText: "text-purple-700",
    winText: "text-blue-500",
    loseText: "text-red-600",
    drawText: "text-slate-600",
  },
  cyber: {
    name: "Cyber Arena",
    background: "bg-gradient-to-br from-cyan-900 via-blue-900 to-purple-900",
    accent: "from-cyan-400 to-purple-600",
    cardBg: "bg-cyan-50/95 backdrop-blur-sm border-cyan-200",
    buttonStyle: "bg-cyan-100 hover:bg-cyan-200 border-cyan-300 text-cyan-900",
    titleText: "text-cyan-400",
    primaryText: "text-cyan-600",
    secondaryText: "text-cyan-700",
    accentText: "text-purple-600",
    labelText: "text-cyan-800",
    descriptionText: "text-cyan-600",
    playerText: "text-cyan-700",
    computerText: "text-purple-700",
    winText: "text-cyan-500",
    loseText: "text-red-600",
    drawText: "text-cyan-600",
  },
}

// Component to render choice display
const ChoiceDisplay = ({ choice, size = "large" }: { choice: Choice; size?: "small" | "large" }) => {
  const imageSize = size === "large" ? 80 : 40
  const textSize = size === "large" ? "text-6xl" : "text-2xl"

  if (choice === "scissors") {
    return <span className={`${textSize} drop-shadow-lg`}>✂️</span>
  }

  return (
    <Image
      src={(choiceImages[choice] as string) || "/placeholder.svg"}
      alt={choiceNames[choice]}
      width={imageSize}
      height={imageSize}
      className="drop-shadow-lg rounded-lg object-cover"
      crossOrigin="anonymous"
    />
  )
}

export default function AdvancedRockPaperScissorsGame() {
  const [gameResult, setGameResult] = useState<GameResponse | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [gameMode, setGameMode] = useState<GameMode>("classic")
  const [theme, setTheme] = useState<Theme>("arena")
  const [gameState, setGameState] = useState<GameState>({
    currentRound: 1,
    totalRounds: 1,
    userScore: 0,
    computerScore: 0,
    gameHistory: [],
    isGameComplete: false,
  })
  const [showResult, setShowResult] = useState(false)
  const [highlightedChoice, setHighlightedChoice] = useState<Choice | null>(null)
  const [speedModeTimer, setSpeedModeTimer] = useState(10)

  const currentTheme = themes[theme]

  useEffect(() => {
    if (gameMode === "speed" && !gameState.isGameComplete && speedModeTimer > 0) {
      const timer = setTimeout(() => setSpeedModeTimer((prev) => prev - 1), 1000)
      return () => clearTimeout(timer)
    } else if (gameMode === "speed" && speedModeTimer === 0) {
      // Auto-play random choice in speed mode
      const choices: Choice[] = ["rock", "paper", "scissors"]
      const randomChoice = choices[Math.floor(Math.random() * choices.length)]
      playGame(randomChoice)
    }
  }, [speedModeTimer, gameMode, gameState.isGameComplete])

  const initializeGame = (mode: GameMode) => {
    const rounds = mode === "bestof3" ? 3 : mode === "tournament" ? 5 : 1
    setGameState({
      currentRound: 1,
      totalRounds: rounds,
      userScore: 0,
      computerScore: 0,
      gameHistory: [],
      isGameComplete: false,
    })
    setGameResult(null)
    setShowResult(false)
    setSpeedModeTimer(10)
  }

  const playGame = async (userChoice: Choice) => {
    if (gameState.isGameComplete) return

    setIsLoading(true)
    setShowResult(false)
    setHighlightedChoice(userChoice)

    try {
      await new Promise((resolve) => setTimeout(resolve, 1000))

      const choices: Choice[] = ["rock", "paper", "scissors"]
      const computerChoice = choices[Math.floor(Math.random() * choices.length)]

      let result: GameResult
      let message: string

      if (userChoice === computerChoice) {
        result = "draw"
        message = "It's a draw!"
      } else if (
        (userChoice === "rock" && computerChoice === "scissors") ||
        (userChoice === "paper" && computerChoice === "rock") ||
        (userChoice === "scissors" && computerChoice === "paper")
      ) {
        result = "win"
        message = "You win this round!"
      } else {
        result = "lose"
        message = "Computer wins this round!"
      }

      const response: GameResponse = {
        user_choice: userChoice,
        computer_choice: computerChoice,
        result,
        message,
      }

      setGameResult(response)

      // Update game state
      const newUserScore = gameState.userScore + (result === "win" ? 1 : 0)
      const newComputerScore = gameState.computerScore + (result === "lose" ? 1 : 0)
      const newHistory = [...gameState.gameHistory, response]
      const newRound = gameState.currentRound + 1

      const isComplete =
        newRound > gameState.totalRounds ||
        (gameMode === "bestof3" && (newUserScore >= 2 || newComputerScore >= 2)) ||
        (gameMode === "tournament" && (newUserScore >= 3 || newComputerScore >= 3))

      setGameState({
        ...gameState,
        currentRound: newRound,
        userScore: newUserScore,
        computerScore: newComputerScore,
        gameHistory: newHistory,
        isGameComplete: isComplete,
      })

      if (gameMode === "speed") {
        setSpeedModeTimer(10)
      }

      setTimeout(() => {
        setShowResult(true)
        setHighlightedChoice(null)
      }, 100)
    } catch (error) {
      console.error("Error playing game:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const resetGame = () => {
    initializeGame(gameMode)
  }

  const getGameModeDescription = (mode: GameMode) => {
    switch (mode) {
      case "classic":
        return "Single round gameplay"
      case "bestof3":
        return "First to win 2 rounds"
      case "tournament":
        return "First to win 3 out of 5 rounds"
      case "speed":
        return "10 seconds per choice!"
      default:
        return ""
    }
  }

  return (
    <div
      className={`min-h-screen ${currentTheme.background} flex flex-col items-center justify-center p-4 relative overflow-hidden`}
    >
      {/* Animated background elements */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-10 left-10 w-32 h-32 bg-white rounded-full animate-pulse"></div>
        <div
          className="absolute bottom-10 right-10 w-24 h-24 bg-white rounded-full animate-pulse"
          style={{ animationDelay: "1s" }}
        ></div>
        <div
          className="absolute top-1/2 left-1/4 w-16 h-16 bg-white rounded-full animate-pulse"
          style={{ animationDelay: "2s" }}
        ></div>
      </div>

      {/* Main Title - Outside the card */}
      <div
        className={`text-6xl font-bold ${currentTheme.titleText} mb-8 drop-shadow-2xl tracking-widest text-center z-10 relative`}
      >
        ROCK PAPER SCISSORS
      </div>

      <Card className={`w-full max-w-4xl mx-auto shadow-2xl ${currentTheme.cardBg} border-2`}>
        <CardHeader className="text-center pb-4">
          {/* Theme and Mode Selection */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-4">
            <div className="flex items-center gap-2">
              <label className={`text-sm font-medium ${currentTheme.labelText}`}>Theme:</label>
              <Select value={theme} onValueChange={(value: Theme) => setTheme(value)}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(themes).map(([key, theme]) => (
                    <SelectItem key={key} value={key}>
                      {theme.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center gap-2">
              <label className={`text-sm font-medium ${currentTheme.labelText}`}>Mode:</label>
              <Select
                value={gameMode}
                onValueChange={(value: GameMode) => {
                  setGameMode(value)
                  initializeGame(value)
                }}
              >
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="classic">Classic</SelectItem>
                  <SelectItem value="bestof3">Best of 3</SelectItem>
                  <SelectItem value="tournament">Tournament</SelectItem>
                  <SelectItem value="speed">Speed Mode</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <p className={`text-sm ${currentTheme.descriptionText} mb-4 font-medium`}>
            {getGameModeDescription(gameMode)}
          </p>

          {/* Game Status */}
          <div className="flex justify-center gap-6 text-sm">
            <Badge variant="outline" className="px-4 py-2">
              Round: {gameState.currentRound}/{gameState.totalRounds}
            </Badge>
            <Badge variant="outline" className="px-4 py-2">
              You: {gameState.userScore}
            </Badge>
            <Badge variant="outline" className="px-4 py-2">
              Computer: {gameState.computerScore}
            </Badge>
          </div>

          {gameMode === "speed" && !gameState.isGameComplete && (
            <div className="mt-4">
              <div
                className={`text-2xl font-bold ${speedModeTimer <= 3 ? "text-red-500 animate-pulse" : currentTheme.accentText}`}
              >
                Time: {speedModeTimer}s
              </div>
            </div>
          )}
        </CardHeader>

        <CardContent className="space-y-6">
          <Tabs defaultValue="game" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="game">Game</TabsTrigger>
              <TabsTrigger value="history">History</TabsTrigger>
            </TabsList>

            <TabsContent value="game" className="space-y-6">
              {/* Game Choices */}
              <div className="grid grid-cols-3 gap-6">
                {(["rock", "paper", "scissors"] as Choice[]).map((choice) => (
                  <Button
                    key={choice}
                    onClick={() => playGame(choice)}
                    disabled={isLoading || gameState.isGameComplete}
                    className={`h-32 transition-all duration-300 hover:scale-110 ${currentTheme.buttonStyle} ${
                      highlightedChoice === choice ? "ring-4 ring-yellow-400 scale-105" : ""
                    } ${isLoading ? "animate-pulse" : "hover:shadow-xl"}`}
                    variant="outline"
                  >
                    <div className="flex flex-col items-center gap-3">
                      <div className="flex items-center justify-center h-20">
                        <ChoiceDisplay choice={choice} size="large" />
                      </div>
                      <span className="text-sm font-bold">{choiceNames[choice]}</span>
                    </div>
                  </Button>
                ))}
              </div>

              {/* Loading State */}
              {isLoading && (
                <div className="text-center py-8">
                  <div className="animate-spin text-6xl mb-4">⚔️</div>
                  <p className={`text-lg font-medium ${currentTheme.primaryText}`}>Battle in progress...</p>
                </div>
              )}

              {/* Game Result */}
              {gameResult && !isLoading && (
                <div
                  className={`text-center py-6 transition-all duration-500 ${
                    showResult ? "opacity-100 transform translate-y-0" : "opacity-0 transform translate-y-4"
                  }`}
                >
                  <div className="flex justify-center items-center gap-12 mb-6">
                    <div className="text-center">
                      <div className="mb-3 animate-bounce flex justify-center h-20 items-center">
                        <ChoiceDisplay choice={gameResult.user_choice} size="large" />
                      </div>
                      <p className={`text-lg font-bold ${currentTheme.playerText}`}>YOU</p>
                    </div>

                    <div className={`text-3xl font-bold ${currentTheme.accentText} animate-pulse`}>⚡VS⚡</div>

                    <div className="text-center">
                      <div
                        className="mb-3 animate-bounce flex justify-center h-20 items-center"
                        style={{ animationDelay: "0.2s" }}
                      >
                        <ChoiceDisplay choice={gameResult.computer_choice} size="large" />
                      </div>
                      <p className={`text-lg font-bold ${currentTheme.computerText}`}>COMPUTER</p>
                    </div>
                  </div>

                  <div
                    className={`text-3xl font-bold mb-4 drop-shadow-lg ${
                      gameResult.result === "win"
                        ? `${currentTheme.winText} animate-bounce`
                        : gameResult.result === "lose"
                          ? `${currentTheme.loseText} animate-pulse`
                          : `${currentTheme.drawText}`
                    }`}
                  >
                    {gameResult.message}
                  </div>

                  <p className={`${currentTheme.secondaryText} mb-4 text-lg font-medium`}>
                    You chose{" "}
                    <span className={`font-bold ${currentTheme.playerText}`}>
                      {choiceNames[gameResult.user_choice]}
                    </span>
                    , computer chose{" "}
                    <span className={`font-bold ${currentTheme.computerText}`}>
                      {choiceNames[gameResult.computer_choice]}
                    </span>
                  </p>

                  {gameState.isGameComplete && (
                    <div
                      className={`text-4xl font-bold mt-6 p-4 rounded-lg border-2 ${
                        gameState.userScore > gameState.computerScore
                          ? `bg-green-100 ${currentTheme.winText} border-green-300`
                          : gameState.userScore < gameState.computerScore
                            ? `bg-red-100 ${currentTheme.loseText} border-red-300`
                            : `bg-yellow-100 ${currentTheme.drawText} border-yellow-300`
                      }`}
                    >
                      {gameState.userScore > gameState.computerScore
                        ? "🏆 YOU WIN THE GAME! 🏆"
                        : gameState.userScore < gameState.computerScore
                          ? "💻 COMPUTER WINS! 💻"
                          : "🤝 GAME TIED! 🤝"}
                    </div>
                  )}
                </div>
              )}

              {/* Reset Button */}
              <div className="text-center">
                <Button
                  onClick={resetGame}
                  variant="outline"
                  className="text-lg px-8 py-3 bg-transparent hover:bg-gray-100"
                >
                  {gameState.isGameComplete ? "New Game" : "Reset Game"}
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="history" className="space-y-4">
              <div className="max-h-64 overflow-y-auto space-y-2">
                {gameState.gameHistory.length === 0 ? (
                  <p className={`text-center ${currentTheme.descriptionText} py-8`}>No games played yet</p>
                ) : (
                  gameState.gameHistory.map((game, index) => (
                    <div
                      key={index}
                      className={`p-3 rounded-lg border ${
                        game.result === "win"
                          ? "bg-green-50 border-green-200"
                          : game.result === "lose"
                            ? "bg-red-50 border-red-200"
                            : "bg-yellow-50 border-yellow-200"
                      }`}
                    >
                      <div className="flex justify-between items-center">
                        <span className={`font-medium ${currentTheme.labelText}`}>Round {index + 1}</span>
                        <span
                          className={`font-bold ${
                            game.result === "win"
                              ? currentTheme.winText
                              : game.result === "lose"
                                ? currentTheme.loseText
                                : currentTheme.drawText
                          }`}
                        >
                          {game.result.toUpperCase()}
                        </span>
                      </div>
                      <div className={`text-sm ${currentTheme.descriptionText} mt-1 flex items-center gap-2`}>
                        <span>You:</span>
                        <ChoiceDisplay choice={game.user_choice} size="small" />
                        <span>vs Computer:</span>
                        <ChoiceDisplay choice={game.computer_choice} size="small" />
                      </div>
                    </div>
                  ))
                )}
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}
